#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 20 17:52:08 2020
Plot mes_pas results as histograms.
@author: armi
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sn
import sys
## To do: This is ugly, fix at some point:
sys.path.insert(1, '../')
#from Filtering_RF_new import plot_RF_test
from Functions_downselection_training_RF import plot_RF_test

#sys.path.append('/home/armi/Dropbox (MIT)/Armiwork2019/2020/Bazan team/Codes/From Antti')
from set_figure_defaults import FigureDefaults
'''
def plot_test(y_test, y_pred, title = None, xlabel = 'Measured $Y = \log_2(MIC)$', ylabel = 'Predicted $Y = \log_2(MIC)$', legend = ['Ideal', 'Result'], saveas = None):
    """
    Plots the results of predicting test set y values using the random forest
    model.
    
    Parameters:
        y_test (df): Experimental test set y values.
        y_pred (df): Predicted test set y values.
        title (str, optional): Title of the plot
        xlabel (str, optional)
        ylabel (str, optional)
        legend (str (2,), optional)
    """
    
    fig, ax  = plt.subplots(1,1)
    fig.set_figheight(5)
    fig.set_figwidth(5)
    ax.scatter(y_test,y_pred, color = 'red')
    ax.plot(np.sort(y_test), np.sort(y_test), '--', color='black')
    ax.set_aspect('equal', 'box')
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.legend(legend)
    if saveas is not None:
        plt.savefig(saveas+'.pdf')
        plt.savefig(saveas+'.svg')
        plt.savefig(saveas+'.png')#, dpi=600)
    plt.show()
'''    
######################################

sn.set_palette('colorblind')

column = 1
ref_data = [r'../Data/Downselection_data_files/y_opt_test_seed3.csv', r'./Data/Downselection_data_files/y_opt_newdata.csv']
preds_prefix = [r'./Models/DMPNN/optfeatures/preds_standard_',
                r'./Models/DMPNN/corfeatures/preds_standard_',
                r'./Models/DMPNN/rdkitfeatures/preds_standard_',
                r'./Models/DMPNN/morgancountfeatures/preds_standard_',
                r'./Models/DMPNN/morganfeatures/preds_standard_',
                r'./Models/DMPNN/nofeatures/preds_standard_',
                r'./Models/DMPNN/optfeatures/preds_ho_',
                r'./Models/DMPNN/corfeatures/preds_ho_',
                r'./Models/DMPNN/rdkitfeatures/preds_ho_',
                r'./Models/DMPNN/morgancountfeatures/preds_ho_',
                r'./Models/DMPNN/morganfeatures/preds_ho_',
                r'./Models/DMPNN/nofeatures/preds_ho_',
                r'./Models/DMPNN/optfeatures/preds_ho_',
                r'./Models/DMPNN/corfeatures/preds_ho_',
                r'./Models/DMPNN/rdkitfeatures/preds_ho_',
                r'./Models/DMPNN/morgancountfeatures/preds_ho_',
                r'./Models/DMPNN/morganfeatures/preds_ho_',
                r'./Models/DMPNN/nofeatures/preds_ho_',
                ]
plot = [True] * 18
ref_data_index = [0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1]
ref_data_type = ['test', 'newdata']
preds_labels = ['Opt. no HO', 'Cor. no HO', 'Biol. no HO', 'cMorg. no HO', 'Morg. no HO', 'Def. no HO',
                'Opt', 'Cor', 'Biol', 'cMorg', 'Morg', 'Def',
                'Opt. newdata', 'Cor. newdata', 'Biol. newdata', 'cMorg. newdata', 'Morg. newdata', 'Def. newdata',
                ]
scatter_fig = r'./Results/chemprop_results/preds_DMPNN_'
preds_start_idx = 0

mystyle = FigureDefaults('nature_comp_mat_tc')

ref = []
for i in ref_data:
    ref.append(pd.read_csv(i, index_col=0))

n_preds = len(preds_prefix)
preds = [None] * n_preds
rmse = [None] * n_preds
for i in range(n_preds):
    if plot[i]:
        preds[i] = pd.read_csv(preds_prefix[i] + ref_data_type[ref_data_index[i]] + '.csv', index_col=0, dtype={'log2mic': np.float64}, na_values = 'Invalid SMILES')
        plot_RF_test(ref[ref_data_index[i]].iloc[:,column], preds[i].iloc[:,column], saveas=scatter_fig  + str(i) + '_' + preds_labels[i])
        rmse[i] = np.sqrt(((preds[i].iloc[:,column] - ref[ref_data_index[i]].iloc[:,column]) ** 2).mean())
    
mystyle = FigureDefaults('nature_comp_mat_sc')

# Create barplot
RMSE_data = pd.DataFrame(data=[[preds_labels[0], rmse[0], 0],
                               [preds_labels[1], rmse[1], 0],
                               [preds_labels[2], rmse[2], 0],
                               [preds_labels[3], rmse[3], 0],
                               [preds_labels[4], rmse[4], 0],
                               [preds_labels[5], rmse[5], 0],
                               [preds_labels[6], rmse[6], 0],
                               [preds_labels[7], rmse[7], 0],
                               [preds_labels[8], rmse[8], 0],
                               [preds_labels[9], rmse[9], 0],
                               [preds_labels[10], rmse[10], 0],
                               [preds_labels[11], rmse[11], 0],
                               [preds_labels[12], rmse[12], 0],
                               [preds_labels[13], rmse[13], 0],
                               [preds_labels[14], rmse[14], 0],
                               [preds_labels[15], rmse[15], 0],
                               [preds_labels[16], rmse[16], 0],
                               [preds_labels[17], rmse[17], 0],
                               ], columns = ['Method', 'RMSE', 'Standard deviation'])#, ['Scaffold split + cross val', 8.46, 0.8], ['Prev + ensemble', 8.5, 0.8], ['+ features', 6.2, 0.66], ['+ hyperparameter opt', 8.43, 0.76]], columns = ['Method', 'RMSE', 'Standard deviation'])
RMSE_data = RMSE_data.reset_index()
plt.figure()
sn.barplot(y='Method', x='RMSE', data = RMSE_data, **{'xerr':RMSE_data['Standard deviation']})
#plt.title(title)
plt.tight_layout()
plt.savefig('../Results/chemprop_results/Regression_RMSE_DMPNN_all.pdf')
plt.show()


preds_prefix = [r'./Models/ffNN/optfeatures/preds_standard_',
                r'./Models/ffNN/corfeatures/preds_standard_',
                r'./Models/ffNN/rdkitfeatures/preds_standard_',
                r'./Models/ffNN/morgancountfeatures/preds_standard_',
                r'./Models/ffNN/morganfeatures/preds_standard_',
                r'./Models/ffNN/optfeatures/preds_ho_',
                r'./Models/ffNN/corfeatures/preds_ho_',
                r'./Models/ffNN/rdkitfeatures/preds_ho_',
                r'./Models/ffNN/morgancountfeatures/preds_ho_',
                r'./Models/ffNN/morganfeatures/preds_ho_',
                r'./Models/ffNN/optfeatures/preds_ho_',
                r'./Models/ffNN/corfeatures/preds_ho_',
                r'./Models/ffNN/rdkitfeatures/preds_ho_',
                r'./Models/ffNN/morgancountfeatures/preds_ho_',
                r'./Models/ffNN/morganfeatures/preds_ho_',
                ]
plot = [True] * 18
ref_data_index = [0,0,0,0,0,0,0,0,0,0,1,1,1,1,1]
ref_data_type = ['test', 'newdata']
preds_labels = ['Opt. no HO', 'Cor. no HO', 'Biol. no HO', 'cMorg. no HO', 'Morg. no HO', 'Def. no HO',
                'Opt', 'Cor', 'Biol', 'cMorg', 'Morg', 'Def',
                'Opt. newdata', 'Cor. newdata', 'Biol. newdata', 'cMorg. newdata', 'Morg. newdata', 'Def. newdata',
                ]
scatter_fig = r'../Results/chemprop_results/preds_ffNN_'
preds_start_idx = 0

mystyle = FigureDefaults('nature_comp_mat_tc')

ref = []
for i in ref_data:
    ref.append(pd.read_csv(i, index_col=0))

n_preds = len(preds_prefix)
preds = [None] * n_preds
rmse = [None] * n_preds
for i in range(n_preds):
    if plot[i]:
        preds[i] = pd.read_csv(preds_prefix[i] + ref_data_type[ref_data_index[i]] + '.csv', index_col=0, dtype={'log2mic': np.float64}, na_values = 'Invalid SMILES')
        plot_RF_test(ref[ref_data_index[i]].iloc[:,column], preds[i].iloc[:,column], saveas=scatter_fig  + str(i) + '_' + preds_labels[i])
        rmse[i] = np.sqrt(((preds[i].iloc[:,column] - ref[ref_data_index[i]].iloc[:,column]) ** 2).mean())
    
mystyle = FigureDefaults('nature_comp_mat_sc')

# Create barplot
RMSE_data = pd.DataFrame(data=[[preds_labels[0], rmse[0], 0],
                               [preds_labels[1], rmse[1], 0],
                               [preds_labels[2], rmse[2], 0],
                               [preds_labels[3], rmse[3], 0],
                               [preds_labels[4], rmse[4], 0],
                               [preds_labels[5], rmse[5], 0],
                               [preds_labels[6], rmse[6], 0],
                               [preds_labels[7], rmse[7], 0],
                               [preds_labels[8], rmse[8], 0],
                               [preds_labels[9], rmse[9], 0],
                               [preds_labels[10], rmse[10], 0],
                               [preds_labels[11], rmse[11], 0],
                               [preds_labels[12], rmse[12], 0],
                               [preds_labels[13], rmse[13], 0],
                               [preds_labels[14], rmse[14], 0],
                               ], columns = ['Method', 'RMSE', 'Standard deviation'])#, ['Scaffold split + cross val', 8.46, 0.8], ['Prev + ensemble', 8.5, 0.8], ['+ features', 6.2, 0.66], ['+ hyperparameter opt', 8.43, 0.76]], columns = ['Method', 'RMSE', 'Standard deviation'])
RMSE_data = RMSE_data.reset_index()
plt.figure()
sn.barplot(y='Method', x='RMSE', data = RMSE_data, **{'xerr':RMSE_data['Standard deviation']})
#plt.title(title)
plt.tight_layout()
plt.savefig('../Results/chemprop_results/RMSE_test_newdata_predictions_ffNN.pdf')
plt.show()
'''
RMSE_data = pd.DataFrame(data=[#[preds_labels[0], rmse[0], 0],
                               #[preds_labels[1], rmse[1], 0],
                               #[preds_labels[2], rmse[2], 0],
                               #[preds_labels[3], rmse[3], 0],
                               #[preds_labels[4], rmse[4], 0],
                               [preds_labels[7], rmse[7], 0],
                               [preds_labels[8], rmse[8], 0],
                               [preds_labels[6], rmse[6], 0],
                               [preds_labels[9], rmse[9], 0],
                               [preds_labels[5], rmse[5], 0]
                               ], columns = ['Method', 'RMSE', 'Standard deviation'])#, ['Scaffold split + cross val', 8.46, 0.8], ['Prev + ensemble', 8.5, 0.8], ['+ features', 6.2, 0.66], ['+ hyperparameter opt', 8.43, 0.76]], columns = ['Method', 'RMSE', 'Standard deviation'])
RMSE_data = RMSE_data.reset_index()
plt.figure()
sn.barplot(y='Method', x='RMSE', data = RMSE_data, **{'xerr':RMSE_data['Standard deviation']})
#plt.title(title)
plt.tight_layout()
plt.savefig('./Results/Regression_RMSE_ffNN.pdf')#_with_validation.pdf')
plt.show()

RMSE_data = pd.DataFrame(data=[#[preds_labels[0], rmse[0], 0],
                               #[preds_labels[1], rmse[1], 0],
                               #[preds_labels[2], rmse[2], 0],
                               #[preds_labels[3], rmse[3], 0],
                               #[preds_labels[4], rmse[4], 0],
                               [preds_labels[7], rmse[7], 0],
                               [preds_labels[8], rmse[8], 0],
                               [preds_labels[6], rmse[6], 0],
                               [preds_labels[9], rmse[9], 0],
                               [preds_labels[5], rmse[5], 0],
                               [preds_labels[12], rmse[12], 0],
                               [preds_labels[13], rmse[13], 0],
                               [preds_labels[11], rmse[11], 0],
                               [preds_labels[14], rmse[14], 0]#,
#                               [preds_labels[10], rmse[10], 0]
                               ], columns = ['Method', 'RMSE', 'Standard deviation'])#, ['Scaffold split + cross val', 8.46, 0.8], ['Prev + ensemble', 8.5, 0.8], ['+ features', 6.2, 0.66], ['+ hyperparameter opt', 8.43, 0.76]], columns = ['Method', 'RMSE', 'Standard deviation'])
RMSE_data = RMSE_data.reset_index()
plt.figure()
sn.barplot(y='Method', x='RMSE', data = RMSE_data, **{'xerr':RMSE_data['Standard deviation']})
#plt.title(title)
plt.tight_layout()
plt.savefig('./Results/Regression_RMSE_ffNN_val.pdf')#_with_validation.pdf')
plt.show()
'''
'''
# Create barplot
RMSE_data = pd.DataFrame(data=[['Default', 2.39, 0],['+ cross val', 2.1, 0.5], ['+ ensemble', 2.1, 0.5], ['+ features', 2.09, 0.5], ['Scaffold split + cross val', 2.9, 0.2], ['Prev + ensemble', 2.9, 0.2], ['Prev + features', 3.0, 0.2], ['+ hyperparameter opt', np.nan, np.nan]], columns = ['Method', 'RMSE', 'Standard deviation'])
RMSE_data = RMSE_data.reset_index()
plt.figure()
sn.barplot(y='Method', x='RMSE', data = RMSE_data, **{'xerr':RMSE_data['Standard deviation']})
#plt.title(title)
plt.show()
#plt.savefig('Regression_K12_RMSE_barplot.png')

'''
