#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 12 16:41:01 2020

@author: armi
"""
import pandas as pd

def read_dmpnn_cv_data(folders, file = 'test_scores.csv'):
        
    keywords = [['Fold', 'rmse'], ['Fold', 'r2']]
    rmse = []
    r2 = []
    for i in folders:
        scores = pd.read_csv(i+file)
        pick_these1 = []
        pick_these2 = []
        for column in scores.columns:
            pick_these1.append((keywords[0][0] in column) and (keywords[0][1] in column))
            pick_these2.append((keywords[1][0] in column) and (keywords[1][1] in column))
        rmse.append(scores.loc[:,pick_these1])
        r2.append(scores.loc[:,pick_these2])
    return rmse, r2

if __name__ == "__main__":
    folders = ['./Models/nofeatures/checkpoints_standard/',
               './Models/nofeatures/checkpoints_ho/',
               './Models/rdkitfeatures/checkpoints_standard/',
               './Models/rdkitfeatures/checkpoints_ho/',
               './Models/RFEfeatures/checkpoints_standard/',
               './Models/RFEfeatures/checkpoints_ho/']
    rmse, r2 = read_dmpnn_cv_data(folders)
    #print(rmse)
    #print(r2)
        