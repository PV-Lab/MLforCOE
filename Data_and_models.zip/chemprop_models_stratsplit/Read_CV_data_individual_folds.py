#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 12 16:41:01 2020

@author: armi
"""
import pandas as pd

def read_dmpnn_cv_data(folders, file = 'test_scores.csv'):
        
    keywords = [['Fold', 'rmse'], ['Fold', 'r2']]
    rmse = []
    r2 = []
    for i in folders:
        scores = pd.read_csv(i+file)
        pick_these1 = []
        pick_these2 = []
        for column in scores.columns:
            pick_these1.append((keywords[0][0] in column) and (keywords[0][1] in column))
            pick_these2.append((keywords[1][0] in column) and (keywords[1][1] in column))
        rmse.append(scores.loc[:,pick_these1])
        r2.append(scores.loc[:,pick_these2])
    return rmse, r2

def read_individual_folds_data(folders, n_folds):
    rmse_all = []
    r2_all = []
    
    for i in range(len(folders)):
        rmse_this = []
        r2_this = []
        for j in range(n_folds):
                rmse, r2 = read_dmpnn_cv_data([folders[i]+'fold_' + str(j) + '/'])
                print(rmse[0].values[0][0])
                rmse_this.append(rmse[0].values[0][0])
                r2_this.append(r2[0].values[0][0])
        rmse_all.append(rmse_this)
        r2_all.append(r2_this)
    print(rmse_all)
    return rmse_all, r2_all

if __name__ == "__main__":
    folders = ['./Models/DMPNN/nofeatures/checkpoints_standard/',
               './Models/DMPNN/nofeatures/checkpoints_ho/',
               './Models/DMPNN/rdkitfeatures/checkpoints_standard/',
               './Models/DMPNN/rdkitfeatures/checkpoints_ho/']
    rmse, r2 = read_individual_folds_data(folders,20)
    
    #rmse, r2 = read_dmpnn_cv_data(folders)
    print(rmse)
    print(r2)
        