#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec  4 12:16:20 2020

@author: armi
"""
import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from V20210405_Compare_R2_RMSE import folders, rmse_dmpnn, model, n_features, RMSE_all_data, R2_all_data, method, fingerprint # DATA is here!
from set_figure_defaults import FigureDefaults

sns.set_palette('colorblind')

violin_rmse_data = pd.DataFrame(data=np.transpose(np.stack([#(
    np.concatenate(RMSE_all_data),
    np.repeat(method, 20), np.repeat(model, 20),
    np.repeat(fingerprint, 20), np.repeat(n_features, 20),
    np.tile(range(20),len(method))
    ])), columns=['RMSE', 'Method', 'Model', 'Fingerprint', '#descriptors', 'Fold'])
violin_rmse_data[['RMSE', '#descriptors', 'Fold']] = violin_rmse_data[[
    'RMSE', '#descriptors', 'Fold']].astype(float)
violin_rmse_data.loc[:,'MSE'] = violin_rmse_data.loc[:,'RMSE']**2

violin_r2_data = pd.DataFrame(data=np.transpose(np.stack([#(
    np.concatenate(R2_all_data),
    np.repeat(method, 20), np.repeat(model, 20),
    np.repeat(fingerprint, 20), np.repeat(n_features, 20),
    np.tile(range(20),len(method))
    ])), columns=['R2', 'Method', 'Model', 'Fingerprint', '#descriptors', 'Fold'])
violin_r2_data[['R2', '#descriptors', 'Fold']] = violin_r2_data[[
    'R2', '#descriptors', 'Fold']].astype(float)
violin_rmse_data.loc[:,'R2'] = violin_r2_data.loc[:,'R2']


###############################################################################
violin_rmse_data_rf = violin_rmse_data[(violin_rmse_data.loc[:,'Model'] == 'RF')]
mystyle = FigureDefaults('nature_comp_mat_tc')
print(mystyle.fontsize)
newPal = dict((val, 'k') for val in fingerprint)
newPal2 = dict((val, [0.7, 0.7, 0.7]) for val in model)
newPal3 = dict((val, 'k') for val in model)
order = ['Init.', 'Var.', 'Cor.', 'Opt.']


g=sns.violinplot(x="Fingerprint", y='RMSE', hue='Model', data=violin_rmse_data_rf, 
                    palette=sns.color_palette()[0:2],
                    dodge=True, linewidth=0, inner=None, order=order)

ax = sns.swarmplot(x="Fingerprint", y='RMSE', hue='Model', 
              data=violin_rmse_data_rf, zorder=1, 
              s=3,
              palette=newPal2, dodge=True, order=order)

g=sns.pointplot(x="Fingerprint", y='RMSE', hue='Model', data=violin_rmse_data_rf,
        zorder=200, 
        linewidth=0.5, ci="sd", #kind='point', 
        palette=newPal3,
        capsize=0.4, errwidth=1, 
        dodge=0.4, legend=False, linestyles=['', ''],
        height=plt.rcParams['figure.figsize'][0],
        aspect=plt.rcParams['figure.figsize'][1]/plt.rcParams['figure.figsize'][0],
        order=order
       )

plt.xticks(rotation=35)
handles, labels = ax.get_legend_handles_labels()
plt.legend(handles[:1], labels[:1], loc='upper right', frameon=True, markerscale=0.5, borderpad=0.2,
           labelspacing=0.2, borderaxespad=0.3, handlelength=1)
plt.tight_layout()
plt.savefig('../Results/chemprop_results/RMSE_violin_rf.pdf')
plt.savefig('../Results/chemprop_results/RMSE_violin_rf.svg')
plt.savefig('../Results/chemprop_results/RMSE_violin_rf.png', dpi=300)
plt.show()

###############################################################################
sns.set_palette('colorblind')


violin_rmse_data_trees_kernels = violin_rmse_data.copy()
violin_rmse_data_trees_kernels.loc[:,'Fingerprint'] = np.repeat(list(map(''.join, zip(fingerprint, [('\n(' + str(x) + ')') for x in n_features]))), 20)
violin_rmse_data_trees_kernels = violin_rmse_data_trees_kernels[(violin_rmse_data_trees_kernels.loc[:,'Model'] == 'RF') |
                                       (violin_rmse_data_trees_kernels.loc[:,'Model'] == 'XGB') |
                                       (violin_rmse_data_trees_kernels.loc[:,'Model'] == 'GP')]
order = ['Init.\n(5259)', 'Var.\n(1662)', 'Cor.\n(233)', 'Opt.\n(21)', 'Morgan\n(2048)', 'cMorgan\n(2048)', 'Biol.\n(200)', 'SMILES\n(15455)', 'SELFIES\n(7061)']
hue_order = ['RF', 'XGB', 'GP']
mystyle = FigureDefaults('nature_comp_mat_dc')
newPal = dict((val, 'k') for val in fingerprint)
newPal2 = dict((val, [0.7, 0.7, 0.7, 0.7]) for val in model)
newPal3 = dict((val, 'k') for val in model)

g = sns.violinplot(x="Fingerprint", y='MSE', hue='Model', data=violin_rmse_data_trees_kernels, 
                    dodge=True, linewidth=0.5, inner=None,
                    palette=np.array(sns.color_palette())[(0,9,2),:],
                    order=order, hue_order = hue_order)
ax = sns.swarmplot(x="Fingerprint", y='MSE', hue='Model', 
              data=violin_rmse_data_trees_kernels, zorder=1, 
              s=3, order=order, hue_order = hue_order,
              palette=newPal2, dodge=0.4)

g=sns.pointplot(x="Fingerprint", y='MSE', hue='Model', data=violin_rmse_data_trees_kernels,
        zorder=200, order=order, hue_order = hue_order,
        linewidth=0.5, ci="sd", #kind='point', 
        palette=newPal3,
        capsize=0.25, errwidth=1, 
        dodge=0.55, legend=False, linestyles=['', '', ''],
        height=plt.rcParams['figure.figsize'][0],
        aspect=plt.rcParams['figure.figsize'][1]/plt.rcParams['figure.figsize'][0]
       )
plt.xticks(rotation=35)
handles, labels = ax.get_legend_handles_labels()
plt.legend(handles[:3], labels[:3], loc='upper left', frameon=True, markerscale=0.5, borderpad=0.2,
           labelspacing=0.2, borderaxespad=0.3, handlelength=1)
plt.tight_layout()

plt.savefig('../Results/chemprop_results/MSE_violin_trees_kernels_nolim.pdf')
plt.savefig('../Results/chemprop_results/MSE_violin_trees_kernels_nolim.svg')
plt.savefig('../Results/chemprop_results/MSE_violin_trees_kernels_nolim.png', dpi=300)
plt.show()


###############################################################################
sns.set_palette('colorblind')


violin_rmse_data_trees_kernels = violin_rmse_data.copy()
violin_rmse_data_trees_kernels.loc[:,'Fingerprint'] = np.repeat(list(map(''.join, zip(fingerprint, [('\n(' + str(x) + ')') for x in n_features]))), 20)
violin_rmse_data_trees_kernels = violin_rmse_data_trees_kernels[(violin_rmse_data_trees_kernels.loc[:,'Model'] == 'RF') |
                                       (violin_rmse_data_trees_kernels.loc[:,'Model'] == 'XGB') |
                                       (violin_rmse_data_trees_kernels.loc[:,'Model'] == 'GP')]
order = ['Init.\n(5259)', 'Var.\n(1662)', 'Cor.\n(233)', 'Opt.\n(21)', 'Morgan\n(2048)', 'cMorgan\n(2048)', 'Biol.\n(200)', 'SMILES\n(15455)', 'SELFIES\n(7061)']
hue_order = ['RF', 'XGB', 'GP']
mystyle = FigureDefaults('nature_comp_mat_dc')
newPal = dict((val, 'k') for val in fingerprint)
newPal2 = dict((val, [0.7, 0.7, 0.7, 0.7]) for val in model)
newPal3 = dict((val, 'k') for val in model)

g = sns.violinplot(x="Fingerprint", y='MSE', hue='Model', data=violin_rmse_data_trees_kernels, 
                    dodge=True, linewidth=0.5, inner=None,
                    palette=np.array(sns.color_palette())[(0,9,2),:],
                    order=order, hue_order = hue_order)
g.set(ylim=(0, 7.5))

ax = sns.swarmplot(x="Fingerprint", y='MSE', hue='Model', 
              data=violin_rmse_data_trees_kernels, zorder=1, 
              s=3, order=order, hue_order = hue_order,
              palette=newPal2, dodge=0.4)

g=sns.pointplot(x="Fingerprint", y='MSE', hue='Model', data=violin_rmse_data_trees_kernels,
        zorder=200, order=order, hue_order = hue_order,
        linewidth=0.5, ci="sd", #kind='point', 
        palette=newPal3,
        capsize=0.25, errwidth=1, 
        dodge=0.55, legend=False, linestyles=['', '', ''],
        height=plt.rcParams['figure.figsize'][0],
        aspect=plt.rcParams['figure.figsize'][1]/plt.rcParams['figure.figsize'][0]
       )
plt.xticks(rotation=35)
handles, labels = ax.get_legend_handles_labels()
plt.legend(handles[:3], labels[:3], loc='upper left', frameon=True, markerscale=0.5, borderpad=0.2,
           labelspacing=0.2, borderaxespad=0.3, handlelength=1)
plt.tight_layout()

plt.savefig('../Results/chemprop_results/MSE_violin_trees_kernels.pdf')
plt.savefig('../Results/chemprop_results/MSE_violin_trees_kernels.svg')
plt.savefig('../Results/chemprop_results/MSE_violin_trees_kernels.png', dpi=300)
plt.show()


###############################################################################
sns.set_palette('colorblind')


violin_rmse_data_trees_kernels = violin_rmse_data.copy()
violin_rmse_data_trees_kernels.loc[:,'Fingerprint'] = np.repeat(list(map(''.join, zip(fingerprint, [('\n(' + str(x) + ')') for x in n_features]))), 20)
violin_rmse_data_trees_kernels = violin_rmse_data_trees_kernels[(violin_rmse_data_trees_kernels.loc[:,'Model'] == 'RF') |
                                       (violin_rmse_data_trees_kernels.loc[:,'Model'] == 'XGB') |
                                       (violin_rmse_data_trees_kernels.loc[:,'Model'] == 'GP')]
order = ['Init.\n(5259)', 'Var.\n(1662)', 'Cor.\n(233)', 'Opt.\n(21)', 'Morgan\n(2048)', 'cMorgan\n(2048)', 'Biol.\n(200)', 'SMILES\n(15455)', 'SELFIES\n(7061)']
hue_order = ['RF', 'XGB', 'GP']
mystyle = FigureDefaults('nature_comp_mat_dc')
newPal = dict((val, 'k') for val in fingerprint)
newPal2 = dict((val, [0.7, 0.7, 0.7, 0.7]) for val in model)
newPal3 = dict((val, 'k') for val in model)

g = sns.violinplot(x="Fingerprint", y='RMSE', hue='Model', data=violin_rmse_data_trees_kernels, 
                    dodge=True, linewidth=0.5, inner=None,
                    palette=np.array(sns.color_palette())[(0,9,2),:],
                    order=order, hue_order = hue_order)
g.set(ylim=(0, 2.5))

ax = sns.swarmplot(x="Fingerprint", y='RMSE', hue='Model', 
              data=violin_rmse_data_trees_kernels, zorder=1, 
              s=3, order=order, hue_order = hue_order,
              palette=newPal2, dodge=0.4)

g=sns.pointplot(x="Fingerprint", y='RMSE', hue='Model', data=violin_rmse_data_trees_kernels,
        zorder=200, order=order, hue_order = hue_order,
        linewidth=0.5, ci="sd", #kind='point', 
        palette=newPal3,
        capsize=0.25, errwidth=1, 
        dodge=0.55, legend=False, linestyles=['', '', ''],
        height=plt.rcParams['figure.figsize'][0],
        aspect=plt.rcParams['figure.figsize'][1]/plt.rcParams['figure.figsize'][0]
       )
plt.xticks(rotation=35)
handles, labels = ax.get_legend_handles_labels()
plt.legend(handles[:3], labels[:3], loc='upper left', frameon=True, markerscale=0.5, borderpad=0.2,
           labelspacing=0.2, borderaxespad=0.3, handlelength=1)
plt.tight_layout()

plt.savefig('../Results/chemprop_results/RMSE_violin_trees_kernels.pdf')
plt.savefig('../Results/chemprop_results/RMSE_violin_trees_kernels.svg')
plt.savefig('../Results/chemprop_results/RMSE_violin_trees_kernels.png', dpi=300)
plt.show()

###############################################################################
violin_rmse_data_nets = violin_rmse_data.copy()
violin_rmse_data_nets.loc[:,'Fingerprint'] = np.repeat(list(map(''.join, zip(fingerprint, [('\n(' + str(x) + ')') for x in n_features]))), 20)
violin_rmse_data_nets = violin_rmse_data_nets[(violin_rmse_data_nets.loc[:,'Model'] == 'ffNN') |
                                       (violin_rmse_data_nets.loc[:,'Model'] == 'DMPNN')]
order = ['Cor.\n(233)', 'Opt.\n(21)', 'Default\n(0)', 'Morgan\n(2048)', 'cMorgan\n(2048)', 'Biol.\n(200)']
hue_order = ['ffNN', 'DMPNN']
palette = np.array(sns.color_palette())[(5,3),:]
mystyle = FigureDefaults('nature_comp_mat_2tc')
newPal = dict((val, 'k') for val in fingerprint)
newPal2 = dict((val, [0.7, 0.7, 0.7]) for val in model)
newPal3 = dict((val, 'k') for val in model)

g=sns.violinplot(x="Fingerprint", y='MSE', hue='Model', data=violin_rmse_data_nets, 
                    dodge=True, linewidth=0.5, inner=None,
                    palette=palette,
                    order = order, hue_order=hue_order)
g.set(ylim=(0, 7.5))

ax = sns.swarmplot(x="Fingerprint", y='MSE', hue='Model', 
              data=violin_rmse_data_nets, zorder=1, 
              s=3, order = order, hue_order=hue_order,
              palette=newPal2, dodge=True)

g=sns.pointplot(x="Fingerprint", y='MSE', hue='Model', data=violin_rmse_data_nets,
        zorder=200, order = order, hue_order=hue_order,
        linewidth=0.5, ci="sd", #kind='point', 
        palette=newPal3,
        capsize=0.25, errwidth=1, 
        dodge=0.4, legend=False, linestyles=['', ''],
        height=plt.rcParams['figure.figsize'][0],
        aspect=plt.rcParams['figure.figsize'][1]/plt.rcParams['figure.figsize'][0]
       )

plt.xticks(rotation=35)
handles, labels = ax.get_legend_handles_labels()
plt.legend(handles[:2], labels[:2], loc='lower right', frameon=True, markerscale=0.5, borderpad=0.2,
           labelspacing=0.2, borderaxespad=0.3, handlelength=1)
plt.tight_layout()

plt.savefig('../Results/chemprop_results/MSE_violin_nets.pdf')
plt.savefig('../Results/chemprop_results/MSE_violin_nets.svg')
plt.savefig('../Results/chemprop_results/MSE_violin_nets.png', dpi=300)

plt.show()

###############################################################################
violin_rmse_data_nets = violin_rmse_data.copy()
violin_rmse_data_nets.loc[:,'Fingerprint'] = np.repeat(list(map(''.join, zip(fingerprint, [('\n(' + str(x) + ')') for x in n_features]))), 20)
violin_rmse_data_nets = violin_rmse_data_nets[(violin_rmse_data_nets.loc[:,'Model'] == 'ffNN') |
                                       (violin_rmse_data_nets.loc[:,'Model'] == 'DMPNN')]
order = ['Cor.\n(233)', 'Opt.\n(21)', 'Default\n(0)', 'Morgan\n(2048)', 'cMorgan\n(2048)', 'Biol.\n(200)']
hue_order = ['ffNN', 'DMPNN']
palette = np.array(sns.color_palette())[(5,3),:]
mystyle = FigureDefaults('nature_comp_mat_2tc')
newPal = dict((val, 'k') for val in fingerprint)
newPal2 = dict((val, [0.7, 0.7, 0.7]) for val in model)
newPal3 = dict((val, 'k') for val in model)

g=sns.violinplot(x="Fingerprint", y='MSE', hue='Model', data=violin_rmse_data_nets, 
                    dodge=True, linewidth=0.5, inner=None,
                    palette=palette,
                    order = order, hue_order=hue_order)
ax = sns.swarmplot(x="Fingerprint", y='MSE', hue='Model', 
              data=violin_rmse_data_nets, zorder=1, 
              s=3, order = order, hue_order=hue_order,
              palette=newPal2, dodge=True)

g=sns.pointplot(x="Fingerprint", y='MSE', hue='Model', data=violin_rmse_data_nets,
        zorder=200, order = order, hue_order=hue_order,
        linewidth=0.5, ci="sd", #kind='point', 
        palette=newPal3,
        capsize=0.25, errwidth=1, 
        dodge=0.4, legend=False, linestyles=['', ''],
        height=plt.rcParams['figure.figsize'][0],
        aspect=plt.rcParams['figure.figsize'][1]/plt.rcParams['figure.figsize'][0]
       )

plt.xticks(rotation=35)
handles, labels = ax.get_legend_handles_labels()
plt.legend(handles[:2], labels[:2], loc='upper right', frameon=True, markerscale=0.5, borderpad=0.2,
           labelspacing=0.2, borderaxespad=0.3, handlelength=1)
plt.tight_layout()

plt.savefig('../Results/chemprop_results/MSE_violin_nets_unlim.pdf')
plt.savefig('../Results/chemprop_results/MSE_violin_nets_unlim.svg')
plt.savefig('../Results/chemprop_results/MSE_violin_nets_unlim.png', dpi=300)

plt.show()

###############################################################################
violin_rmse_data_nets = violin_rmse_data.copy()
violin_rmse_data_nets.loc[:,'Fingerprint'] = np.repeat(list(map(''.join, zip(fingerprint, [('\n(' + str(x) + ')') for x in n_features]))), 20)
violin_rmse_data_nets = violin_rmse_data_nets[(violin_rmse_data_nets.loc[:,'Model'] == 'ffNN') |
                                       (violin_rmse_data_nets.loc[:,'Model'] == 'DMPNN')]
order = ['Cor.\n(233)', 'Opt.\n(21)', 'Default\n(0)', 'Morgan\n(2048)', 'cMorgan\n(2048)', 'Biol.\n(200)']
hue_order = ['ffNN', 'DMPNN']
palette = np.array(sns.color_palette())[(5,3),:]
mystyle = FigureDefaults('nature_comp_mat_2tc')
newPal = dict((val, 'k') for val in fingerprint)
newPal2 = dict((val, [0.7, 0.7, 0.7]) for val in model)
newPal3 = dict((val, 'k') for val in model)

g=sns.violinplot(x="Fingerprint", y='RMSE', hue='Model', data=violin_rmse_data_nets, 
                    dodge=True, linewidth=0.5, inner=None,
                    palette=palette,
                    order = order, hue_order=hue_order)
ax = sns.swarmplot(x="Fingerprint", y='RMSE', hue='Model', 
              data=violin_rmse_data_nets, zorder=1, 
              s=3, order = order, hue_order=hue_order,
              palette=newPal2, dodge=True)

g=sns.pointplot(x="Fingerprint", y='RMSE', hue='Model', data=violin_rmse_data_nets,
        zorder=200, order = order, hue_order=hue_order,
        linewidth=0.5, ci="sd", #kind='point', 
        palette=newPal3,
        capsize=0.25, errwidth=1, 
        dodge=0.4, legend=False, linestyles=['', ''],
        height=plt.rcParams['figure.figsize'][0],
        aspect=plt.rcParams['figure.figsize'][1]/plt.rcParams['figure.figsize'][0]
       )

plt.xticks(rotation=35)
handles, labels = ax.get_legend_handles_labels()
plt.legend(handles[:2], labels[:2], loc='upper right', frameon=True, markerscale=0.5, borderpad=0.2,
           labelspacing=0.2, borderaxespad=0.3, handlelength=1)
plt.tight_layout()

plt.savefig('../Results/chemprop_results/RMSE_violin_nets_unlim.pdf')
plt.savefig('../Results/chemprop_results/RMSE_violin_nets_unlim.svg')
plt.savefig('../Results/chemprop_results/RMSE_violin_nets_unlim.png', dpi=300)

plt.show()

